
import gc
import statistics
import sys
import time
import tracemalloc


def benchmark(sort_function, input_list, iterations=5):
    
    if iterations < 1:
        raise ValueError('iterations must be positive')
    if tracemalloc.is_tracing():
        raise RuntimeError('Stop existing tracemalloc tracing before benchmarking')
    expected = sorted(input_list)
    # Input objects exist before tracing: count each distinct object once.
    seen = set()
    input_bytes = sys.getsizeof(input_list)
    for item in input_list:
        if id(item) not in seen:
            seen.add(id(item))
            input_bytes += sys.getsizeof(item)
    del seen
    def check(work, result):
        if (work if result is None else result) != expected:
            raise AssertionError('Sort output differs from sorted(input_list)')
    work = input_list.copy()
    result = sort_function(work)  # one untimed warm-up
    check(work, result)
    del work, result
    times, peaks = [], []
    for _ in range(iterations):
        gc.collect()
        work = input_list.copy()  # outside timing; never reuse sorted output
        start = time.perf_counter()
        result = sort_function(work)
        elapsed = time.perf_counter() - start
        check(work, result)  # validation outside timing
        times.append(elapsed * 1000)
        del work, result
        gc.collect()
        tracemalloc.start()
        try:
            work = input_list.copy()  # include work copy in traced peak
            result = sort_function(work)
            _, peak = tracemalloc.get_traced_memory()
        finally:
            tracemalloc.stop()
        check(work, result)
        peaks.append(peak)
        del work, result
    peak_bytes = input_bytes + max(peaks)
    return dict(algorithm=sort_function.__name__, iterations=iterations,
                average_ms=statistics.mean(times), min_ms=min(times),
                max_ms=max(times), peak_mb=peak_bytes / 1_000_000,
                traced_extra_peak_bytes=max(peaks), input_bytes=input_bytes,
                time_pass=statistics.mean(times) < 400,
                memory_pass=peak_bytes < 50_000_000,
                timing_samples_ms=times, traced_peak_samples_bytes=peaks)
