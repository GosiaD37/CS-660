
def quick_sort(a):
    # Iterative Hoare partition avoids Python recursion limits.
    stack = [(0, len(a) - 1)]
    while stack:
        lo, hi = stack.pop()
        if lo >= hi:
            continue
        pivot = a[(lo + hi) // 2]
        i, j = lo, hi
        while i <= j:
            while a[i] < pivot:
                i += 1
            while a[j] > pivot:
                j -= 1
            if i <= j:
                a[i], a[j] = a[j], a[i]
                i += 1
                j -= 1
        # Process smaller partition first to limit pending stack growth.
        parts = [(lo, j), (i, hi)]
        parts.sort(key=lambda p: p[1] - p[0], reverse=True)
        stack.extend(p for p in parts if p[0] < p[1])
    return a


def merge_sort(a):
    n = len(a)
    buffer = [None] * n
    def merge(lo, hi):
        if hi - lo <= 1:
            return
        mid = (lo + hi) // 2
        merge(lo, mid)
        merge(mid, hi)
        i, j = lo, mid
        for k in range(lo, hi):
            if i < mid and (j >= hi or a[i] <= a[j]):
                buffer[k] = a[i]
                i += 1
            else:
                buffer[k] = a[j]
                j += 1
        for k in range(lo, hi):
            a[k] = buffer[k]
    merge(0, n)
    return a


def heap_sort(a):
    def sift(root, end):
        while 2 * root + 1 < end:
            child = 2 * root + 1
            if child + 1 < end and a[child] < a[child + 1]:
                child += 1
            if a[root] >= a[child]:
                break
            a[root], a[child] = a[child], a[root]
            root = child
    for root in range(len(a) // 2 - 1, -1, -1):
        sift(root, len(a))
    for end in range(len(a) - 1, 0, -1):
        a[0], a[end] = a[end], a[0]
        sift(0, end)
    return a
