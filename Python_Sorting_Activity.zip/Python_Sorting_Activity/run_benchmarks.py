import argparse
import json
import platform
import random
import sys
from pathlib import Path
from benchmark import benchmark
from sorts import quick_sort, merge_sort, heap_sort


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--size', type=int, default=100_000)
    parser.add_argument('--iterations', type=int, default=5)
    parser.add_argument('--seed', type=int, default=660)
    parser.add_argument('--output', default='benchmark_results.json')
    args = parser.parse_args()
    if args.size < 0 or args.iterations < 1:
        parser.error('size must be nonnegative and iterations positive')
    rng = random.Random(args.seed)
    data = [rng.randint(-1_000_000, 1_000_000) for _ in range(args.size)]
    results = []
    for fn in (quick_sort, merge_sort, heap_sort):
        r = benchmark(fn, data, args.iterations)
        results.append(r)
        print(f"{fn.__name__:12} {r['average_ms']:9.2f} ms  {r['peak_mb']:7.3f} MB  "
              f"time={'PASS' if r['time_pass'] else 'FAIL'}  "
              f"memory={'PASS' if r['memory_pass'] else 'FAIL'}", flush=True)
    report = dict(environment=dict(python=sys.version, implementation=platform.python_implementation(),
                                   platform=platform.platform(), processor=platform.processor()),
                  size=args.size, seed=args.seed, results=results)
    Path(args.output).write_text(json.dumps(report, indent=2), encoding='utf-8')
    print('Saved:', args.output)


if __name__ == '__main__':
    main()
